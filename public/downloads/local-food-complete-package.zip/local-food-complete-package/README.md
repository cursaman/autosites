# AI와 함께 14일 만에 웹서비스 만들기 - 실습 패키지

## 구성
- ebook/: 전자책 PDF
- source/local-food/: 완성 프로젝트 소스
- documents/: PROJECT, PRD, AGENTS, DATABASE, API, QA 문서
- database/schema.sql: Supabase 스키마
- templates/: AI 작업지시서, 오류 해결 프롬프트, 14일 체크리스트

## 시작
1. source/local-food 폴더에서 `npm install`
2. `.env.example`을 `.env.local`로 복사
3. 본인의 Kakao/Supabase/AI 설정 입력
4. Supabase SQL Editor에서 database/schema.sql 실행
5. `npm run dev`
6. 배포 전 `npm run build`

## 주의
실제 API Key는 포함되어 있지 않습니다.
AI 설정은 제공자에 맞게 AI_API_URL / AI_API_KEY / AI_MODEL을 설정하세요.
