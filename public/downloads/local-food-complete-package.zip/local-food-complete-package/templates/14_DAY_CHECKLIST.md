# Local Food 14-Day Checklist

- [ ] DAY 01 화면 / 카드 / 반응형
- [ ] DAY 02 Kakao Local API / 실제 검색
- [ ] DAY 03 Supabase / 찜 저장
- [ ] DAY 04 회원가입 / 로그인 / 사용자별 찜 / RLS
- [ ] DAY 05 별점 / 후기 / CRUD
- [ ] DAY 06 Kakao Map / Marker
- [ ] DAY 07 현재 위치 / 거리 반경
- [ ] DAY 08 조건 필터 / 랜덤 추천
- [ ] DAY 09 AI 자연어 추천 / 실제 후보 검증
- [ ] DAY 10 관리자 / 권한
- [ ] DAY 11 GitHub / Vercel / 환경변수
- [ ] DAY 12 Metadata / Manifest / UX
- [ ] DAY 13 보안 / 전체 QA / Build
- [ ] DAY 14 README / Screenshot / Portfolio
