# 🍴 우리 동네 맛집 (local-food)

Kakao Local API의 실제 장소 데이터를 검색하고, Supabase 회원/찜/후기,
Kakao 지도, 현재 위치, 랜덤 추천, AI 자연어 추천, 관리자 대시보드까지
연습하는 14일 Next.js 종합 프로젝트입니다.

## 시작

```bash
npm install
cp .env.example .env.local
npm run dev
```

Windows에서는 `.env.example`을 복사해 `.env.local`로 이름을 바꿔도 됩니다.

## 중요

- 실제 API 키는 `.env.local`에만 넣으세요.
- `.env.local`은 GitHub에 올리지 마세요.
- `supabase/schema.sql`을 Supabase SQL Editor에서 실행하세요.
- 첫 관리자는 SQL Editor에서 자신의 `profiles.role`을 `admin`으로 변경하세요.
- AI 기능은 `AI_API_URL`, `AI_API_KEY`, `AI_MODEL`을 설정하지 않으면 안내 메시지를 반환합니다.

## 주요 URL

- `/` 맛집 검색
- `/recommend` 랜덤/AI 추천
- `/my` 내 맛집/후기
- `/signup` 회원가입
- `/login` 로그인
- `/admin` 관리자 대시보드
