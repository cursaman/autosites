export type Place = {
  id: string;
  place_name: string;
  category_name: string;
  address_name: string;
  road_address_name: string;
  phone: string;
  place_url: string;
  x: string;
  y: string;
  distance?: string;
};

export type Favorite = Place & {
  favoriteId: number;
  rating: number | null;
  review: string | null;
  created_at?: string;
};
