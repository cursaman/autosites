"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { getSupabaseBrowserClient } from "@/lib/supabase";

export default function Header() {
  const [email, setEmail] = useState("");
  useEffect(() => {
    try {
      const supabase = getSupabaseBrowserClient();
      supabase.auth.getUser().then(({ data }) => setEmail(data.user?.email ?? ""));
    } catch {}
  }, []);
  async function logout() {
    const supabase = getSupabaseBrowserClient();
    await supabase.auth.signOut();
    location.href = "/";
  }
  return (
    <header className="header">
      <Link className="brand" href="/">🍴 우리 동네 맛집</Link>
      <nav>
        <Link href="/">맛집찾기</Link>
        <Link href="/recommend">오늘 뭐 먹지?</Link>
        <Link href="/my">내 맛집</Link>
        <Link href="/admin">관리자</Link>
        {email ? <button className="linkButton" onClick={logout}>로그아웃</button> : <Link href="/login">로그인</Link>}
      </nav>
    </header>
  );
}
