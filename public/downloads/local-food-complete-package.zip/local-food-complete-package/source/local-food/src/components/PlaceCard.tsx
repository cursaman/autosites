"use client";
import type { Place } from "@/types/place";

export default function PlaceCard({
  place, favorite, onFavorite, onSelect,
}: {
  place: Place;
  favorite?: boolean;
  onFavorite?: (place: Place) => void;
  onSelect?: (place: Place) => void;
}) {
  return (
    <article className="card" onClick={() => onSelect?.(place)}>
      <div className="cardTop">
        <div>
          <h3>{place.place_name}</h3>
          <p className="muted">{place.category_name}</p>
        </div>
        {onFavorite && (
          <button className="heart" onClick={(e) => { e.stopPropagation(); onFavorite(place); }}>
            {favorite ? "♥" : "♡"}
          </button>
        )}
      </div>
      <p>📍 {place.road_address_name || place.address_name || "주소 정보 없음"}</p>
      {place.distance && <p>🚶 약 {Number(place.distance).toLocaleString()}m</p>}
      {place.phone && <p>☎ {place.phone}</p>}
      {place.place_url && <a href={place.place_url} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()}>Kakao 상세보기 →</a>}
    </article>
  );
}
