"use client";
import { useEffect, useRef } from "react";
import type { Place } from "@/types/place";

declare global {
  interface Window { kakao: any; }
}

export default function KakaoMap({
  places,
  selectedPlace,
  myLocation,
}: {
  places: Place[];
  selectedPlace?: Place | null;
  myLocation?: { lat: number; lng: number } | null;
}) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const key = process.env.NEXT_PUBLIC_KAKAO_MAP_JS_KEY;
    if (!key || !ref.current) return;

    const draw = () => {
      window.kakao.maps.load(() => {
        if (!ref.current) return;
        const first = selectedPlace ?? places[0];
        const center = first
          ? new window.kakao.maps.LatLng(Number(first.y), Number(first.x))
          : myLocation
          ? new window.kakao.maps.LatLng(myLocation.lat, myLocation.lng)
          : new window.kakao.maps.LatLng(35.191, 129.068);
        const map = new window.kakao.maps.Map(ref.current, { center, level: 5 });

        places.forEach((place) => {
          const position = new window.kakao.maps.LatLng(Number(place.y), Number(place.x));
          const marker = new window.kakao.maps.Marker({ map, position });
          const info = new window.kakao.maps.InfoWindow({ content: `<div style="padding:6px;font-size:12px">${place.place_name}</div>` });
          window.kakao.maps.event.addListener(marker, "click", () => info.open(map, marker));
        });

        if (myLocation) {
          new window.kakao.maps.Marker({
            map,
            position: new window.kakao.maps.LatLng(myLocation.lat, myLocation.lng),
          });
        }
      });
    };

    if (window.kakao?.maps) draw();
    else {
      const old = document.getElementById("kakao-map-sdk");
      if (old) old.addEventListener("load", draw, { once: true });
      else {
        const script = document.createElement("script");
        script.id = "kakao-map-sdk";
        script.async = true;
        script.src = `https://dapi.kakao.com/v2/maps/sdk.js?appkey=${key}&autoload=false`;
        script.onload = draw;
        document.head.appendChild(script);
      }
    }
  }, [places, selectedPlace, myLocation]);

  if (!process.env.NEXT_PUBLIC_KAKAO_MAP_JS_KEY)
    return <div className="map placeholder">Kakao JavaScript Key를 설정하면 지도가 표시됩니다.</div>;

  return <div ref={ref} className="map" />;
}
