"use client";
import { useState } from "react";
import PlaceCard from "@/components/PlaceCard";
import type { Place } from "@/types/place";

export default function RecommendPage(){
  const [places,setPlaces]=useState<Place[]>([]); const [selected,setSelected]=useState<Place|null>(null);
  const [food,setFood]=useState("한식"); const [distance,setDistance]=useState(3000); const [request,setRequest]=useState("");
  const [ai,setAi]=useState<{place:Place;reason:string}[]>([]); const [loading,setLoading]=useState(false); const [message,setMessage]=useState("");

  async function candidates(){
    const res=await fetch(`/api/places?query=${encodeURIComponent(`부산 ${food} 맛집`)}`); const data=await res.json();
    if(!res.ok)throw new Error(data.error); const list:Place[]=data.places??[]; setPlaces(list); return list;
  }
  async function random(){
    setMessage(""); try{const list=places.length?places:await candidates(); const filtered=list.filter(p=>!p.distance||Number(p.distance)<=distance);
      if(!filtered.length)return setMessage("추천 후보가 없습니다."); setSelected(filtered[Math.floor(Math.random()*filtered.length)]);}
    catch(e){setMessage(e instanceof Error?e.message:"추천 실패");}
  }
  async function aiRecommend(){
    if(!request.trim())return setMessage("원하는 상황을 자연어로 입력해주세요.");
    setLoading(true);setMessage("");setAi([]);
    try{const list=places.length?places:await candidates(); const res=await fetch("/api/recommend",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({request,distance,places:list})});
      const data=await res.json(); if(!res.ok)throw new Error(data.error); const map=new Map(list.map(p=>[p.id,p]));
      setAi((data.recommendations??[]).map((r:{placeId:string;reason:string})=>({place:map.get(String(r.placeId)),reason:r.reason})).filter((v:{place?:Place})=>v.place) as {place:Place;reason:string}[]);
    }catch(e){setMessage(e instanceof Error?e.message:"AI 추천 실패");}finally{setLoading(false);}
  }
  return <><section className="hero small"><h1>🎲 오늘 뭐 먹지?</h1><p>먼저 간단한 랜덤 추천, 다음은 자연어 AI 추천을 사용해보세요.</p></section>
    <section className="panel">
      <div className="formGrid"><select value={food} onChange={e=>setFood(e.target.value)}>{["한식","고기","일식","중식","카페"].map(v=><option key={v}>{v}</option>)}</select>
      <select value={distance} onChange={e=>setDistance(Number(e.target.value))}>{[500,1000,3000,5000].map(v=><option key={v} value={v}>{v<1000?`${v}m`:`${v/1000}km`}</option>)}</select></div>
      <button onClick={random}>🎲 랜덤 추천</button>
      {selected&&<div className="featured"><PlaceCard place={selected}/></div>}
      <hr/><textarea value={request} onChange={e=>setRequest(e.target.value)} placeholder="예: 비 오는 날 가족과 따뜻한 음식을 먹고 싶어요."/>
      <button disabled={loading} onClick={aiRecommend}>{loading?"AI가 고르는 중...":"🤖 AI 추천"}</button>
      {message&&<p className="notice">{message}</p>}
    </section>
    <section className="grid">{ai.map(({place,reason})=><div key={place.id}><PlaceCard place={place}/><p className="reason">🤖 {reason}</p></div>)}</section>
  </>;
}
