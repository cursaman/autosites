"use client";
import { useState } from "react";
import Link from "next/link";
import { getSupabaseBrowserClient } from "@/lib/supabase";

export default function SignupPage() {
  const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [message,setMessage]=useState("");
  async function submit(e:React.FormEvent){ e.preventDefault(); setMessage("");
    try {
      const supabase=getSupabaseBrowserClient();
      const {error}=await supabase.auth.signUp({email,password,options:{emailRedirectTo:location.origin}});
      setMessage(error?error.message:"가입 요청이 완료되었습니다. 이메일 인증 설정에 따라 메일을 확인해주세요.");
    } catch { setMessage("Supabase 설정을 확인해주세요."); }
  }
  return <section className="auth panel"><h1>회원가입</h1><form onSubmit={submit}>
    <input type="email" required placeholder="이메일" value={email} onChange={e=>setEmail(e.target.value)}/>
    <input type="password" required minLength={6} placeholder="비밀번호 6자 이상" value={password} onChange={e=>setPassword(e.target.value)}/>
    <button>회원가입</button></form>{message&&<p className="notice">{message}</p>}<p><Link href="/login">이미 회원인가요? 로그인</Link></p></section>
}
