"use client";
import { useEffect, useState } from "react";
import { getSupabaseBrowserClient } from "@/lib/supabase";

type Fav={id:number;place_name:string;review:string|null;rating:number|null;created_at:string;user_id:string};
export default function AdminPage(){
  const [allowed,setAllowed]=useState<boolean|null>(null); const [stats,setStats]=useState({users:0,favorites:0,reviews:0,places:0}); const [rows,setRows]=useState<Fav[]>([]); const [message,setMessage]=useState("");
  async function load(){
    try{
      const s=getSupabaseBrowserClient(); const {data:{user}}=await s.auth.getUser(); if(!user){location.href="/login";return;}
      const {data:profile}=await s.from("profiles").select("role").eq("id",user.id).single();
      if(profile?.role!=="admin"){setAllowed(false);return;} setAllowed(true);
      const [{count:users},{data:favs,count:favorites}]=await Promise.all([
        s.from("profiles").select("*",{count:"exact",head:true}),
        s.from("favorites").select("id,place_name,review,rating,created_at,user_id",{count:"exact"}).order("created_at",{ascending:false})
      ]);
      const list=(favs??[]) as Fav[]; const reviews=list.filter(v=>v.review).length; const places=new Set(list.map(v=>v.place_name)).size;
      setStats({users:users??0,favorites:favorites??0,reviews,places}); setRows(list.slice(0,10));
    }catch{setMessage("관리자 데이터를 불러오지 못했습니다.");}
  }
  useEffect(()=>{load();},[]);
  async function clearReview(id:number){const s=getSupabaseBrowserClient();await s.from("favorites").update({rating:null,review:null}).eq("id",id);load();}
  if(allowed===null)return <p className="notice">관리자 권한 확인 중...</p>;
  if(!allowed)return <section className="panel"><h1>접근 권한이 없습니다.</h1><p>관리자 계정만 사용할 수 있습니다.</p></section>;
  return <><section className="hero small"><h1>📊 관리자 대시보드</h1><p>서비스의 기본 이용 현황을 확인합니다.</p></section>
    <section className="stats">{Object.entries({회원:stats.users,찜:stats.favorites,후기:stats.reviews,"저장 맛집":stats.places}).map(([k,v])=><div className="stat" key={k}><span>{k}</span><strong>{v}</strong></div>)}</section>
    {message&&<p className="notice">{message}</p>}
    <section className="panel"><h2>최근 활동</h2>{rows.map(r=><div className="adminRow" key={r.id}><div><strong>{r.place_name}</strong><p>{r.rating?`★ ${r.rating}`:""} {r.review||"찜 저장"}</p></div>{r.review&&<button className="secondary" onClick={()=>clearReview(r.id)}>후기 초기화</button>}</div>)}</section>
  </>;
}
