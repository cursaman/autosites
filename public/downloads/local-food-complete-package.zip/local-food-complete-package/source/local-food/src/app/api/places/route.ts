import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
  const query = request.nextUrl.searchParams.get("query")?.trim();
  const x = request.nextUrl.searchParams.get("x");
  const y = request.nextUrl.searchParams.get("y");
  const radius = request.nextUrl.searchParams.get("radius");
  const key = process.env.KAKAO_REST_API_KEY;

  if (!query) return NextResponse.json({ error: "검색어를 입력해주세요." }, { status: 400 });
  if (!key) return NextResponse.json({ error: "Kakao REST API Key가 설정되지 않았습니다." }, { status: 500 });

  const params = new URLSearchParams({ query, page: "1", size: "15", sort: x && y ? "distance" : "accuracy" });
  if (x && y) { params.set("x", x); params.set("y", y); }
  if (radius) params.set("radius", String(Math.min(Number(radius) || 1000, 20000)));

  const response = await fetch(`https://dapi.kakao.com/v2/local/search/keyword.json?${params}`, {
    headers: { Authorization: `KakaoAK ${key}` },
    cache: "no-store",
  });

  if (!response.ok) return NextResponse.json({ error: "Kakao 장소 검색에 실패했습니다." }, { status: response.status });
  const data = await response.json();
  return NextResponse.json({ query, totalCount: data.meta?.total_count ?? 0, places: data.documents ?? [] });
}
