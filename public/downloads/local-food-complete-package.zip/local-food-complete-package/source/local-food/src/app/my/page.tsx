"use client";
import { useEffect, useState } from "react";
import { getSupabaseBrowserClient } from "@/lib/supabase";

type Row = {
  id:number; place_name:string; category_name:string|null; road_address_name:string|null;
  address_name:string|null; place_url:string|null; rating:number|null; review:string|null; created_at:string;
};

export default function MyPage(){
  const [rows,setRows]=useState<Row[]>([]); const [message,setMessage]=useState("불러오는 중...");
  async function load(){
    try{
      const supabase=getSupabaseBrowserClient(); const {data:{user}}=await supabase.auth.getUser();
      if(!user){location.href="/login";return;}
      const {data,error}=await supabase.from("favorites").select("*").eq("user_id",user.id).order("created_at",{ascending:false});
      if(error) throw error; setRows(data??[]); setMessage(data?.length?"":"아직 찜한 맛집이 없습니다.");
    }catch{setMessage("내 맛집을 불러오지 못했습니다.");}
  }
  useEffect(()=>{load();},[]);
  async function save(id:number,rating:number|null,review:string){
    if(review.length>100)return alert("후기는 100자까지 입력할 수 있습니다.");
    const supabase=getSupabaseBrowserClient(); const {data:{user}}=await supabase.auth.getUser(); if(!user)return;
    await supabase.from("favorites").update({rating,review:review.trim()||null}).eq("id",id).eq("user_id",user.id); load();
  }
  async function remove(id:number){
    const supabase=getSupabaseBrowserClient(); const {data:{user}}=await supabase.auth.getUser(); if(!user)return;
    await supabase.from("favorites").delete().eq("id",id).eq("user_id",user.id); load();
  }
  return <><section className="hero small"><h1>❤️ 내 맛집</h1><p>찜한 맛집에 나만의 별점과 한줄 후기를 남겨보세요.</p></section>
    {message&&<p className="notice">{message}</p>}
    <section className="grid">{rows.map(row=><ReviewCard key={row.id} row={row} onSave={save} onRemove={remove}/>)}</section></>;
}
function ReviewCard({row,onSave,onRemove}:{row:Row;onSave:(id:number,r:number|null,v:string)=>void;onRemove:(id:number)=>void}){
  const [rating,setRating]=useState<number|null>(row.rating); const [review,setReview]=useState(row.review??"");
  return <article className="card"><h3>{row.place_name}</h3><p className="muted">{row.category_name}</p><p>📍 {row.road_address_name||row.address_name}</p>
    <div className="stars">{[1,2,3,4,5].map(n=><button key={n} onClick={()=>setRating(n)}>{(rating??0)>=n?"★":"☆"}</button>)}</div>
    <textarea maxLength={100} value={review} onChange={e=>setReview(e.target.value)} placeholder="한줄 후기 (100자)"/>
    <div className="actions"><button onClick={()=>onSave(row.id,rating,review)}>저장</button><button className="secondary" onClick={()=>onRemove(row.id)}>찜 삭제</button></div>
  </article>
}
