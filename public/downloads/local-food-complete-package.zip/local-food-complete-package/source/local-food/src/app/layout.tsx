import type { Metadata } from "next";
import "./globals.css";
import Header from "@/components/Header";

export const metadata: Metadata = {
  title: { default: "우리 동네 맛집", template: "%s | 우리 동네 맛집" },
  description: "내 주변 맛집을 검색하고 지도, 찜, 후기와 AI 추천까지 이용해보세요.",
  manifest: "/manifest.webmanifest",
  openGraph: {
    title: "우리 동네 맛집",
    description: "내 주변의 실제 맛집을 검색하고 추천받아보세요.",
    type: "website",
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="ko">
      <body>
        <Header />
        <main className="container">{children}</main>
      </body>
    </html>
  );
}
