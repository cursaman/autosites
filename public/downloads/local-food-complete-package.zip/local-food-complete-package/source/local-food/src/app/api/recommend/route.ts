import { NextRequest, NextResponse } from "next/server";
import type { Place } from "@/types/place";

export async function POST(request: NextRequest) {
  const body = await request.json();
  const userRequest = String(body.request ?? "").trim();
  const places = (Array.isArray(body.places) ? body.places : []) as Place[];

  if (!userRequest || places.length === 0)
    return NextResponse.json({ error: "요청 내용과 실제 맛집 후보가 필요합니다." }, { status: 400 });

  const url = process.env.AI_API_URL;
  const key = process.env.AI_API_KEY;
  const model = process.env.AI_MODEL;
  if (!url || !key || !model)
    return NextResponse.json({ error: "AI 환경변수가 아직 설정되지 않았습니다." }, { status: 503 });

  const candidates = places.slice(0, 15).map(p => ({
    id: p.id, name: p.place_name, category: p.category_name,
    address: p.road_address_name || p.address_name, distance: p.distance || null,
  }));

  const prompt = `사용자 요청: ${userRequest}
예산(선택): ${body.budget ?? ""}
거리조건(선택): ${body.distance ?? ""}

후보 JSON:
${JSON.stringify(candidates)}

규칙:
- 후보에 있는 장소만 선택한다.
- 최대 3개.
- 확인되지 않은 가격, 주차, 영업시간, 분위기, 평점을 만들지 않는다.
- 반드시 {"recommendations":[{"placeId":"후보 id","reason":"짧은 이유"}]} JSON만 반환한다.`;

  const ai = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model,
      messages: [
        { role: "system", content: "실제 후보 목록 안에서만 맛집을 추천하는 도우미다." },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" }
    }),
  });

  if (!ai.ok) return NextResponse.json({ error: "AI 추천 요청에 실패했습니다." }, { status: 502 });
  const raw = await ai.json();
  const content = raw.choices?.[0]?.message?.content;
  try {
    const parsed = JSON.parse(content);
    const validIds = new Set(places.map(p => p.id));
    const recommendations = (parsed.recommendations ?? [])
      .filter((r: { placeId?: string }) => r.placeId && validIds.has(String(r.placeId)))
      .slice(0, 3);
    return NextResponse.json({ recommendations });
  } catch {
    return NextResponse.json({ error: "AI 응답 형식을 해석하지 못했습니다." }, { status: 502 });
  }
}
