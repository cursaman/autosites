"use client";
import { useState } from "react";
import Link from "next/link";
import { getSupabaseBrowserClient } from "@/lib/supabase";

export default function LoginPage() {
  const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [message,setMessage]=useState("");
  async function submit(e:React.FormEvent){ e.preventDefault(); setMessage("");
    try {
      const supabase=getSupabaseBrowserClient();
      const {error}=await supabase.auth.signInWithPassword({email,password});
      if(error) setMessage(error.message); else location.href="/";
    } catch { setMessage("Supabase 설정을 확인해주세요."); }
  }
  return <section className="auth panel"><h1>로그인</h1><form onSubmit={submit}>
    <input type="email" required placeholder="이메일" value={email} onChange={e=>setEmail(e.target.value)}/>
    <input type="password" required placeholder="비밀번호" value={password} onChange={e=>setPassword(e.target.value)}/>
    <button>로그인</button></form>{message&&<p className="notice">{message}</p>}<p><Link href="/signup">회원가입</Link></p></section>
}
