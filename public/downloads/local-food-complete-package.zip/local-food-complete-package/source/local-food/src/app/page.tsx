"use client";
import { useEffect, useMemo, useState } from "react";
import KakaoMap from "@/components/KakaoMap";
import PlaceCard from "@/components/PlaceCard";
import { getSupabaseBrowserClient } from "@/lib/supabase";
import type { Place } from "@/types/place";

const quick = ["부산 사직동 맛집", "부산 사직동 한식", "부산 사직동 고기 맛집", "부산 사직동 카페", "부산 사직동 일식"];

export default function HomePage() {
  const [query, setQuery] = useState("부산 사직동 맛집");
  const [places, setPlaces] = useState<Place[]>([]);
  const [selected, setSelected] = useState<Place | null>(null);
  const [favoriteIds, setFavoriteIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [myLocation, setMyLocation] = useState<{lat:number;lng:number}|null>(null);
  const [radius, setRadius] = useState(1000);

  async function loadFavorites() {
    try {
      const supabase = getSupabaseBrowserClient();
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return setFavoriteIds(new Set());
      const { data } = await supabase.from("favorites").select("kakao_place_id").eq("user_id", user.id);
      setFavoriteIds(new Set((data ?? []).map(v => v.kakao_place_id)));
    } catch {}
  }
  useEffect(() => { loadFavorites(); }, []);

  async function search(nextQuery = query, location = myLocation) {
    if (!nextQuery.trim()) return setMessage("검색어를 입력해주세요.");
    setLoading(true); setMessage("");
    const p = new URLSearchParams({ query: nextQuery.trim() });
    if (location) { p.set("x", String(location.lng)); p.set("y", String(location.lat)); p.set("radius", String(radius)); }
    try {
      const res = await fetch(`/api/places?${p}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "검색 실패");
      setPlaces(data.places ?? []);
      setSelected(data.places?.[0] ?? null);
      if (!data.places?.length) setMessage("맛집을 찾지 못했습니다. 다른 검색어를 사용해보세요.");
    } catch (e) { setMessage(e instanceof Error ? e.message : "맛집 정보를 불러오지 못했습니다."); }
    finally { setLoading(false); }
  }

  async function nearby() {
    if (!navigator.geolocation) return setMessage("이 브라우저에서는 위치 기능을 사용할 수 없습니다.");
    setLoading(true);
    navigator.geolocation.getCurrentPosition(
      pos => {
        const loc = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        setMyLocation(loc); search("맛집", loc);
      },
      () => { setLoading(false); setMessage("현재 위치를 사용할 수 없습니다. 지역명을 직접 검색해주세요."); },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }

  async function toggleFavorite(place: Place) {
    try {
      const supabase = getSupabaseBrowserClient();
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { location.href = "/login"; return; }
      if (favoriteIds.has(place.id)) {
        await supabase.from("favorites").delete().eq("user_id", user.id).eq("kakao_place_id", place.id);
      } else {
        await supabase.from("favorites").insert({
          user_id: user.id, kakao_place_id: place.id, place_name: place.place_name,
          category_name: place.category_name, address_name: place.address_name,
          road_address_name: place.road_address_name, phone: place.phone,
          place_url: place.place_url, x: place.x, y: place.y, distance: place.distance ?? null
        });
      }
      await loadFavorites();
    } catch { setMessage("찜 처리에 실패했습니다."); }
  }

  const sorted = useMemo(() => [...places].sort((a,b) => Number(a.distance || 0)-Number(b.distance || 0)), [places]);

  return (
    <>
      <section className="hero">
        <span className="eyebrow">LOCAL FOOD FINDER</span>
        <h1>오늘, 우리 동네에서<br/>뭐 먹지?</h1>
        <p>실제 맛집 검색부터 지도·찜·추천까지 한 번에.</p>
      </section>
      <section className="panel">
        <form className="searchRow" onSubmit={e => { e.preventDefault(); search(query, null); }}>
          <input value={query} maxLength={50} onChange={e => setQuery(e.target.value)} placeholder="예: 부산 사직동 맛집"/>
          <button disabled={loading}>{loading ? "검색 중..." : "검색"}</button>
        </form>
        <div className="chips">{quick.map(q => <button key={q} onClick={() => { setQuery(q); search(q, null); }}>{q.replace("부산 사직동 ","")}</button>)}</div>
        <div className="locationRow">
          <button onClick={nearby} disabled={loading}>📍 내 주변 맛집</button>
          {[500,1000,3000,5000].map(r => <button className={radius===r?"active":""} key={r} onClick={() => setRadius(r)}>{r<1000?`${r}m`:`${r/1000}km`}</button>)}
        </div>
        {message && <p className="notice">{message}</p>}
      </section>
      <KakaoMap places={places} selectedPlace={selected} myLocation={myLocation}/>
      <div className="sectionTitle"><h2>검색 결과</h2><span>{places.length}곳</span></div>
      <section className="grid">
        {sorted.map(place => <PlaceCard key={place.id} place={place} favorite={favoriteIds.has(place.id)} onFavorite={toggleFavorite} onSelect={setSelected}/>)}
      </section>
    </>
  );
}
