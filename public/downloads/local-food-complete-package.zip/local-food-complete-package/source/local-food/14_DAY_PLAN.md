# 1~14일차 요구사항 요약

1. 화면/카드/반응형
2. Kakao Local API
3. Supabase 찜
4. Auth + 사용자별 데이터
5. 별점/후기 CRUD
6. Kakao 지도/마커
7. Geolocation + 반경
8. 랜덤 추천
9. AI 자연어 추천
10. 관리자 대시보드
11. GitHub/Vercel 배포
12. SEO/PWA/UX
13. RLS/보안/QA
14. README/포트폴리오/최종 시연

상세 기준은 PROJECT.md, PRD.md, QA_CHECKLIST.md를 따른다.
