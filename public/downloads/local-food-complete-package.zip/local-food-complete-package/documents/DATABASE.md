# DATABASE.md

## profiles
- id uuid PK, auth.users 참조
- email text
- role text: user | admin
- created_at timestamptz

회원가입 시 trigger로 자동 생성한다.

## favorites
- id bigint identity PK
- user_id uuid
- kakao_place_id text
- place_name text
- category_name text
- address_name text
- road_address_name text
- phone text
- place_url text
- x text
- y text
- distance text
- rating integer null (1~5)
- review text null (최대 100자)
- created_at timestamptz
- UNIQUE(user_id, kakao_place_id)

## RLS
favorites:
- SELECT/INSERT/UPDATE/DELETE 모두 `auth.uid() = user_id`

profiles:
- 일반 사용자는 자신의 profile 조회
- admin은 전체 profile 조회 가능
- role 변경은 일반 클라이언트에서 허용하지 않음

실제 SQL은 `supabase/schema.sql` 참고.
