# API.md

## GET /api/places
Kakao Local Keyword Search를 서버에서 호출한다.

Query:
- `query` 필수
- `x`, `y` 선택
- `radius` 선택 (최대 20000m)

Response:
`{ query, totalCount, places }`

place:
id, place_name, category_name, address_name, road_address_name,
phone, place_url, x, y, distance.

`KAKAO_REST_API_KEY`는 서버에서만 사용한다.

## Kakao Maps
브라우저 SDK는 `NEXT_PUBLIC_KAKAO_MAP_JS_KEY` 사용.
검색 결과의 x=경도, y=위도를 마커로 표시한다.

## POST /api/recommend
Input:
`{ request, budget?, distance?, places }`

AI 규칙:
- 제공된 places 안에서만 선택
- 최대 3개
- placeId + 짧은 reason
- 확인되지 않은 사실 생성 금지

AI 환경변수:
`AI_API_URL`, `AI_API_KEY`, `AI_MODEL`

## Supabase
Auth: signUp / signInWithPassword / signOut / getUser
DB: favorites SELECT/INSERT/UPDATE/DELETE
