# PROJECT.md — local-food

## 프로젝트
**우리 동네 맛집** — 실제 주변 맛집을 검색하고 지도, 찜, 후기, 추천까지 제공하는 교육용 풀스택 웹서비스.

## 기술
Next.js App Router / React / TypeScript / Kakao Local API / Kakao Maps /
Supabase PostgreSQL + Auth + RLS / AI API / GitHub / Vercel.

## 핵심 흐름
검색 → 실제 Kakao 장소 → 지도 → 회원가입/로그인 → 찜 → 내 맛집 →
별점/후기 → 랜덤 추천 → AI 추천 → 관리자 → 배포/QA.

## 1~14일차
1. Next.js 화면과 샘플 카드
2. Kakao Local API 실제 데이터
3. Supabase 찜
4. Supabase Auth + 사용자별 찜
5. 별점/후기 CRUD
6. Kakao Map + 마커
7. 현재 위치 + 반경 검색
8. 규칙/랜덤 기반 “오늘 뭐 먹지?”
9. AI 자연어 추천 — 실제 Kakao 후보 안에서만
10. 관리자 대시보드
11. GitHub → Vercel 배포/환경변수
12. SEO/PWA/UX/성능
13. RLS/보안/예외처리/전체 QA
14. README/포트폴리오/최종 시연

## 완료 기준
`npm run build` 성공, 모바일 주요 기능 정상, RLS 정상,
일반회원 `/admin` 차단, Secret GitHub 미노출, Vercel 운영 정상.
