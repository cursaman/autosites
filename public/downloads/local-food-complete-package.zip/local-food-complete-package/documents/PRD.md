# PRD.md

## 사용자
주변 맛집을 찾고 싶은 사람, 오늘 메뉴를 결정하기 어려운 사람,
맛집을 저장하고 개인 별점/후기를 기록하고 싶은 사람.

## 기능 요구사항
- 지역명 자유검색과 빠른 카테고리 검색
- Kakao Local API 실제 장소 최대 15개
- Kakao 지도/마커/카드 선택 연동
- 현재 위치 및 500m/1km/3km/5km 반경
- 회원가입/로그인/로그아웃
- 사용자별 찜/찜취소
- `/my`에서 별점 1~5, 후기 100자, 수정/삭제
- 음식 종류/거리 기반 랜덤 추천
- 자연어 AI 추천 최대 3곳
- AI는 전달받은 실제 후보 외 장소를 만들지 않음
- 관리자: 회원/찜/후기/저장 맛집 통계, 최근 활동, 후기 관리
- Loading/Empty/Error/Success 상태
- 모바일 반응형
- SEO metadata / Open Graph / manifest

## 보안
- Secret은 서버 환경변수
- RLS로 본인 favorites만 CRUD
- `/admin`은 profiles.role=admin만 허용
- Service Role Key를 브라우저에 노출하지 않음
